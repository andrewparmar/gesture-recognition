
To make a sample ECCV paper, copy the contents of this directory
somewhere, and type

 latex eccv2016submission
 bibtex eccv2016submission
 latex eccv2016submission
 latex eccv2016submission

or 

 pdflatex eccv2016submission
 bibtex eccv2016submission
 pdflatex eccv2016submission
 pdflatex eccv2016submission
